from MyMathLib import SimpleGeometry
